import{f as k,n as y,S as m,s as O,g as _,i as U,D as $,l as z,F as Y,a as X}from"./storage-Bpr3OdzM.js";const G=/[\u00A5\uFFE5]|\b\d[\d,.]*\s*\u5143/,H=/(\u00A5|\uFFE5)\s*([0-9]+(?:,[0-9]{3})*(?:\.[0-9]+)?)|([0-9]+(?:,[0-9]{3})*(?:\.[0-9]+)?)\s*\u5143/g,K=/[0-9]+(?:,[0-9]{3})*(?:\.[0-9]+)?/,W=/\s*≈\s*[^\s·|;,)\]]+(?:\s*[A-Z]{3})?/g;function w(e){return G.test(e)}function M(e){const t=e.replaceAll(",",""),r=Number.parseFloat(t);return Number.isFinite(r)?r:null}function T(e){const t=e.match(K);return t?M(t[0]):null}function R(e){const t=e.trim();return t==="¥"||t==="￥"}function C(e){const t=e.trim();return t?/^[\d,.\s-]+$/.test(t)&&/\d/.test(t):!1}function F(e,t,r){return e.replace(W,"").replace(H,(o,a,d,i)=>{const s=M(d||i);return s===null?o:`${o} ≈ ${k(s,t,r)}`})}const A="tbcc-price-badge-styles",p="tbcc-price-badge",j=new Set(["SCRIPT","STYLE","NOSCRIPT","TEXTAREA","INPUT"]),u=new Map,g=new Set,b=new WeakMap;let c=$,l=y(Y),E=!1;function D(){if(document.getElementById(A))return;const e=document.createElement("style");e.id=A,e.textContent=`
.${p} {
  display: inline-flex;
  align-items: center;
  margin-left: 6px;
  padding: 1px 6px;
  border-radius: 6px;
  border: 1px solid rgba(234, 88, 12, 0.24);
  background-color: rgba(249, 115, 22, 0.09);
  color: #c2410c;
  font-family: "Segoe UI Variable", "Segoe UI", Inter, system-ui, sans-serif;
  font-size: clamp(11px, 0.72em, 13px);
  font-weight: 600;
  line-height: 1.35;
  letter-spacing: 0.01em;
  font-variant-numeric: tabular-nums;
  white-space: nowrap;
  vertical-align: middle;
  text-decoration: none;
  box-sizing: border-box;
}
.${p}[data-tbcc-surface="dark"] {
  border-color: rgba(251, 146, 60, 0.34);
  background-color: rgba(249, 115, 22, 0.16);
  color: #fdba74;
}
`,(document.head||document.documentElement).appendChild(e)}function h(e){let t=e;for(;t;){const n=window.getComputedStyle(t).backgroundColor.match(/rgba?\((\d+),\s*(\d+),\s*(\d+)(?:,\s*([\d.]+))?\)/);if(n&&(n[4]===void 0?1:Number.parseFloat(n[4]))>.25){const a=Number(n[1]),d=Number(n[2]),i=Number(n[3]);return(.299*a+.587*d+.114*i)/255<.45?"dark":"light"}t=t.parentElement}return"light"}function q(){return`1 CNY = ${X(c,_(l,c))} ${c} · Taobao Convert`}function L(e){let t=e.previousElementSibling,r=0;for(;t&&r<4;){if(t instanceof HTMLElement&&R(t.textContent??""))return t;t=t.previousElementSibling,r+=1}return null}function I(e){const t=L(e);if(!e.isConnected||!t){g.delete(e);return}const r=T(e.textContent??"");if(r===null)return;let n=b.get(e);if(!n){const i=e.nextElementSibling;i instanceof HTMLElement&&i.dataset.tbccStructuredMarker==="1"&&(n=i,b.set(e,n))}const o=e.parentElement;if(o){const i=o.querySelectorAll('[data-tbcc-structured-marker="1"]');for(let f=0;f<i.length;f+=1){const s=i[f];if(s===n)continue;const x=s.previousElementSibling;x&&b.get(x)===s||s.remove()}}const a=`≈ ${k(r,c,l)}`,d=q();if(n){n.className=p,n.dataset.tbccSurface=h(e),n.title=d,n.textContent=a;return}o&&(D(),n=document.createElement("span"),n.className=p,n.dataset.tbccStructuredMarker="1",n.dataset.tbccSurface=h(e),n.title=d,n.textContent=a,e.insertAdjacentElement("afterend",n),b.set(e,n))}function Z(e){const t=e.parentElement;if(!t||t.dataset.tbccStructuredMarker==="1")return null;const r=(e.nodeValue??"").trim();if(R(r)){let n=t.nextElementSibling,o=0;for(;n&&o<4;){if(n instanceof HTMLElement&&n.dataset.tbccStructuredMarker!=="1"&&C(n.textContent??"")&&T(n.textContent??"")!==null)return n;n=n.nextElementSibling,o+=1}}return C(r)&&T(r)!==null&&L(t)?t:null}function S(e){const t=Z(e);t&&(g.add(t),I(t))}function J(e){if(!e.nodeValue||!e.nodeValue.trim())return!1;const t=e.parentElement;return!(!t||t.dataset.tbccStructuredMarker==="1"||j.has(t.tagName)||t.isContentEditable)}function N(e){const t=u.get(e);if(!t)return;const r=F(t,c,l);e.nodeValue!==r&&(E=!0,e.nodeValue=r,E=!1)}function V(e){if(!J(e))return;S(e);const t=e.nodeValue??"";w(t)&&(u.set(e,t),N(e))}function P(e){if(!e)return;const t=document.createTreeWalker(e,NodeFilter.SHOW_TEXT);let r=t.nextNode();for(;r;)V(r),r=t.nextNode()}function v(){for(const[e]of u){if(!e.isConnected){u.delete(e);continue}N(e)}for(const e of g){if(!e.isConnected){g.delete(e);continue}I(e)}}function Q(){new MutationObserver(t=>{if(!E)for(const r of t){if(r.type==="childList"){for(const n of r.addedNodes)if(n.nodeType===Node.TEXT_NODE)V(n);else if(n.nodeType===Node.ELEMENT_NODE){const o=n;o.dataset.tbccStructuredMarker!=="1"&&P(o)}}if(r.type==="characterData"&&r.target.nodeType===Node.TEXT_NODE){const n=r.target,o=n.nodeValue??"";S(n);const a=u.get(n);if(a&&o===F(a,c,l))continue;if(!w(o)){u.delete(n);continue}u.set(n,o),N(n),S(n)}}}).observe(document.documentElement,{childList:!0,subtree:!0,characterData:!0})}function B(e,t){return Number.isFinite(_(e,t))}async function ee(){try{const e=await chrome.runtime.sendMessage({type:"tbcc:getSettings"});if(e!=null&&e.currency&&U(e.currency)&&(c=e.currency),e!=null&&e.rates){const t=y(e.rates);B(t,c)&&(l=t)}}catch{const e=await z();c=e.currency,l=e.rates}}chrome.storage.onChanged.addListener((e,t)=>{if(t==="sync"&&e[m.currency]&&(c=O(e[m.currency].newValue),v()),t==="local"&&e[m.rates]){const r=y(e[m.rates].newValue);B(r,c)&&(l=r,v())}});ee().catch(()=>{}).finally(()=>{D(),P(document.body),Q()});
